import { OfficeRepository } from '@/lib/repository/OfficeRepository';
import { NextRequest, NextResponse } from 'next/server';

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const companyId = searchParams.get('companyId');

  try {
    const offices = await OfficeRepository.findMany();
    return NextResponse.json(offices, { status: 200 });
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to fetch offices' },
      { status: 500 },
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const { name, address, latitude, longitude, companyId } = await req.json();

    if (!companyId) {
      return NextResponse.json(
        { error: 'Missing required field: companyId' },
        { status: 400 },
      );
    }

    const office = await OfficeRepository.create({
      name,
      address,
      latitude,
      longitude,
      companyId: Number(companyId),
    });

    return NextResponse.json(office, { status: 201 });
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to create office' },
      { status: 500 },
    );
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const { id } = await req.json();

    if (!id) {
      return NextResponse.json(
        { error: 'Missing required field: id' },
        { status: 400 },
      );
    }

    await OfficeRepository.delete(Number(id));

    return NextResponse.json(
      { message: 'Office deleted successfully' },
      { status: 200 },
    );
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to delete office' },
      { status: 500 },
    );
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const { id, ...data } = await req.json();

    if (!id) {
      return NextResponse.json(
        { error: 'Missing required field: id' },
        { status: 400 },
      );
    }

    const updatedOffice = await OfficeRepository.update(Number(id), data);

    if (!updatedOffice) {
      return NextResponse.json({ error: 'Office not found' }, { status: 404 });
    }

    return NextResponse.json(updatedOffice, { status: 200 });
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to update office' },
      { status: 500 },
    );
  }
}
