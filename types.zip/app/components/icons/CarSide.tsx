import * as React from "react";
import type { SVGProps } from "react";
const SvgCarSide = (props: SVGProps<SVGSVGElement>) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 640 512"
    width="1em"
    height="1em"
    {...props}
  >
    <path
      fill="currentColor"
      d="M147 106.7 117.2 192h122.9V96h-77.9c-6.8 0-12.9 4.3-15.1 10.7zm-98.4 87.2L86.5 85.6C97.8 53.5 128.1 32 162.1 32H360c25.2 0 48.9 11.9 64 32l96.2 128.3C587.1 196.5 640 252.1 640 320v16c0 35.3-28.7 64-64 64h-16.4c-4 44.9-41.7 80-87.6 80s-83.6-35.1-87.6-80H239.7c-4 44.9-41.7 80-87.6 80s-83.6-35.1-87.6-80h-.4c-35.3 0-64-28.7-64-64v-80c0-30.1 20.7-55.3 48.6-62.1zM440 192l-67.2-89.6c-3-4-7.8-6.4-12.8-6.4h-72v96zM152 432a40 40 0 1 0 0-80 40 40 0 1 0 0 80m360-40a40 40 0 1 0-80 0 40 40 0 1 0 80 0"
    />
  </svg>
);
export default SvgCarSide;
